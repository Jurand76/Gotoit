// using System;
// using System.Net.NetworkInformation;
// using System.Reflection;
// using shops;
// using Xunit;

// namespace Shops.Tests
// {
//     public class TypeTests
//     {
//         [Fact]
//         public void StringsBehaveLikeValueType()
//         {
//             var x = "Castorama";
//             var upper = this.MakeUppercase(x);
             
//             Assert.Equal("Castorama",x);
//             Assert.Equal("Castorama",upper);
//         }

//         private string MakeUppercase (string parameter)
//         {
//             return parameter.ToUpper();
//         }
//     }
// }
